

#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
//#include <JRMemory/MemScan.h>
#import <AdSupport/AdSupport.h>
#import <CommonCrypto/CommonCrypto.h>
#include <mach-o/dyld.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIControl.h>

#import "Library/BoniOSLoad.h"
#import "Library/JHPP.h"
#import "Library/JHDragView.h"
#import "Library/bonioshax.h"
#import "Library/patch.h"
#import "static-inline.h" // thêm

@interface BoniOS()
//@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, strong) UIAlertView* alertView;
@property (nonatomic) int remainingSeconds;
@end


#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^

@implementation BoniOS

static BoniOS *extraInfo;
static BOOL MenDeal;
UIWindow *mainWindow;

+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

mainWindow = [UIApplication sharedApplication].keyWindow;

        extraInfo =  [BoniOS new];
        [extraInfo initTapGes];
        [extraInfo tapIconView];

     [self bonios];
    });
}



+(void)bonios{  

//NSString *TextHere = @"BoniOSHAX.VN ";

UILabel *myLabel0 = [[UILabel alloc]
initWithFrame:CGRectMake(50, -6, 580, 65)];
myLabel0.textColor = [UIColor cyanColor];
myLabel0.font = [UIFont fontWithName:@"AvenirNext-HeavyItalic" size:13];
myLabel0.numberOfLines = 1;
myLabel0.text = [NSString stringWithFormat:@"‍ctc hax"];
myLabel0.textAlignment = NSTextAlignmentCenter;
myLabel0.shadowColor = [UIColor whiteColor];
myLabel0.shadowOffset = CGSizeMake(0.70,0.70); 
[mainWindow addSubview:myLabel0];


    UIButton *menuView = [[UIButton alloc] 
    initWithFrame:CGRectMake(60, 45, 100, 100)];
    menuView.backgroundColor= [UIColor clearColor];
[menuView addTarget:self action:@selector(buttonDragged:withEvent:)
         forControlEvents:UIControlEventTouchDragInside];
    [mainWindow addSubview:menuView];





//button rời
    UIView *view = [[UIView alloc] 
    initWithFrame:CGRectMake(0, 0, 78, 72)];
    view.backgroundColor= [UIColor blueColor];
    view.layer.borderWidth = 2.5;//sửa đổi độ dày viền tại đây
    view.layer.borderColor = [UIColor colorWithRed:0.40 green:0.80 blue:1.00 alpha:1.0].CGColor;//màu của viền
view.layer.cornerRadius = 11.0;
view.layer.masksToBounds = true;

    [menuView addSubview:view];



    UILabel *tsw = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 80, 30)];
tsw.textColor = [UIColor blackColor];
tsw.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:11];
tsw.numberOfLines = 1;
tsw.textAlignment = NSTextAlignmentCenter;
tsw.text = [NSString stringWithFormat:@"ON HACK"];
tsw.shadowColor = [UIColor clearColor];
tsw.shadowOffset = CGSizeMake(1.1,1.1); 
tsw.backgroundColor = [UIColor clearColor];

[view addSubview:tsw];



    UISwitch *sw1 = [[UISwitch alloc] 
initWithFrame: CGRectMake(12, 35, 35, 35)];

sw1.layer.borderWidth = 2.5;
sw1.layer.cornerRadius = 5.0;
sw1.layer.borderColor = [UIColor colorWithRed:0.40 green:0.80 blue:1.00 alpha:1.0].CGColor;
sw1.transform = CGAffineTransformMakeScale(1.00, 1.00);
sw1.backgroundColor = [UIColor redColor];
sw1.layer.cornerRadius = 16;
sw1.thumbTintColor = [UIColor blackColor];
sw1.onTintColor = [UIColor greenColor];
    [sw1 addTarget:self                action:@selector(switchIsChanged:)                forControlEvents:UIControlEventValueChanged];

    [view addSubview:sw1];


}

+ (void)switchIsChanged:(UISwitch *)paramSender {
    
    if ([paramSender isOn]) {
//on
//ENCRYPTOFFSET("0x1039770AC"), ENCRYPTHEX("0xE003271EC0035FD6");
ActiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5331A08"), (char*)[NSSENCRYPT("360080D2") UTF8String]);//Map
      StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework",  0x5331A08 , "360080D2");

      ActiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5EEC550"), (char*)[NSSENCRYPT("1F2003D5") UTF8String]);//rank
      StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework",  0x5EEC550 , "1F2003D5");
      
      ActiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5E3AD60"), (char*)[NSSENCRYPT("C0035FD6") UTF8String]);//fps2
      StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework",  0x5E3AD60 , "C0035FD6");
      
      ActiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5FE1214"), (char*)[NSSENCRYPT("1F2003D5") UTF8String]);//botro
      StaticInlineHookPatch("Frameworks/UnityFramework.framework/UnityFramework",  0x5E21A50 , "1F2003D5");

    } else {
//off
//ENCRYPTOFFSET("0x1039770AC"), ENCRYPTHEX("0xE003271EC0035FD6");
DeactiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5331A08"), (char*)[NSSENCRYPT("360080D2") UTF8String]);//Map
      DeactiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5EEC550"), (char*)[NSSENCRYPT("1F2003D5") UTF8String]);//rank
      DeactiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5E3AD60"), (char*)[NSSENCRYPT("C0035FD6") UTF8String]);//FPS2
      DeactiveCodePatch((char*)[NSSENCRYPT("Frameworks/UnityFramework.framework/UnityFramework") UTF8String], ENCRYPTOFFSET("0x5FE1214"), (char*)[NSSENCRYPT("1F2003D5") UTF8String]);//botro 
    }
}

-(void)initTapGes
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;
    tap.numberOfTouchesRequired = 3;
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];
}

-(void)tapIconView
{
    JHDragView *view = [[JHPP currentViewController].view viewWithTag:100];
    if (!view) {
        view = [[JHDragView alloc] init];
        view.tag = 100;
        [[JHPP currentViewController].view addSubview:view];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped:)];
        tap.numberOfTapsRequired = 1;
        [view addGestureRecognizer:tap];
        
    }
    
    if (!MenDeal) {
        view.hidden = NO;
    } else {
        view.hidden = YES;
    }
    
    MenDeal = !MenDeal;
}

+ (void)buttonDragged:(UIButton *)button withEvent:(UIEvent *)event {
    UITouch *touch = [[event touchesForView:button] anyObject];
    
    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;
    
    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
}




@end
